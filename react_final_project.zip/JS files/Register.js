import React, { Component } from 'react';

class Register extends Component {
  loginUser() {
    this.props.loginRegister({ "name": this.refs.name_reg.value, "username": this.refs.username_reg.value, "password": this.refs.password_reg.value })
  }
  render() {
    console.log(this.props.db_users)
    return (
      <div class="labels">
        <h3>Register</h3>

        <form className="form-horizontal">
          <div className="form-group">
            <label className="control-label col-md-6">Name:</label>
            <input className="col-md-1" type="text" placeholder="Name" ref="name_reg" required/>
          </div>
          <div className="form-group">
            <label className="control-label col-md-6">Username:</label>
            <input className="col-md-1" type="text" placeholder="Username" ref="username_reg" required />
          </div>
          <div className="form-group">
            <label className="control-label col-md-6">Password:</label>
            <input className="col-md-1" type="password" placeholder="Password" ref="password_reg" required/>
          </div>
          <input className="col-md-offset-6 col-md-10" type="submit" onClick={this.loginUser.bind(this)} />
        </form>
      </div>
    )
  }
}

export default Register;