import React, { Component } from 'react'

class City extends Component {
    constructor() {
        super()
        this.state = {
            cities: ["Bangalore", "Mumbai", "New Delhi", "Pune", "Hyderabad"]
        }
    }
    render() {
        var cities = this.state.cities.map(function (i) {
            return <option value={i}>{i}</option>
        })
        return cities
    }
}

class State extends Component {
    constructor() {
        super()
        this.state = {
            states: ["Delhi", "Karnataka", "Maharastra", "Telangana"],
        }
    }
    render() {
        var states = this.state.states.map(function (i) {
            return <option value={i}>{i}</option>
        })
        return states
    }
}

class EditCustomer extends Component {
    editCustomer() {
        var customerData = {
            "fname": this.refs.cfname.value,
            "lname": this.refs.clname.value,
            "city": this.refs.ccity.value,
            "state": this.refs.cstate.value,
            "email": this.refs.cemail.value
        }
        this.props.editCustomer(customerData);
    }
    render() {
        return (
            <div>
                <h3>Edit Customer</h3>
                <form className="form-horizontal">
                    <div className="form-group">
                        <label className="control-label col-md-6">First Name:
                                </label>
                        <input className="col-md-1" type="text" ref="cfname" />
                    </div>
                    <div className="form-group">
                        <label className="control-label col-md-6">Last Name:
                        </label>
                        <input className="col-md-1" type="text" ref="clname" />
                    </div>
                    <div className="form-group">
                        <label className="control-label col-md-6">City:
                        </label>
                        <select className="col-md-1" ref="ccity"><City /></select></div>
                    <div className="form-group">
                        <label className="control-label col-md-6">State:
                            </label>
                        <select className="col-md-1" ref="cstate"><State /></select>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-md-6">
                            Email:</label>
                        <input className="col-md-1" type="email" ref="cemail" />
                    </div>
                    <input className="col-md-offset-6 col-md-10" type="submit" onClick={this.editCustomer.bind(this)} value="Submit Changes" />
                </form>
            </div>
        )
    }
}
export default EditCustomer