import React, { Component } from 'react';
import SearchCustomer from './SearchCustomer';

class DisplayCustomers extends Component {
    render() {
        var customers = this.props.customers
        var tableData = customers.map(function (i) {
            console.log(i)
            return <tr><td>{i.fname}</td><td>{i.lname}</td><td>{i.city}</td><td>{i.state}</td><td>{i.email}</td></tr>
        })
        console.log(tableData)
        return (
            <center>
                <h3>Customer Details</h3>
                <table border="solid">
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Email</th>
                    {tableData}
                </table>
            </center>
        )
    }
}

class City extends Component {
    constructor() {
        super()
        this.state = {
            cities: ["Bangalore", "Mumbai", "New Delhi", "Pune", "Hyderabad"]
        }
    }
    render() {
        var cities = this.state.cities.map(function (i) {
            return <option value={i}>{i}</option>
        })
        return cities
    }
}

class State extends Component {
    constructor() {
        super()
        this.state = {
            states: ["Delhi", "Karnataka", "Maharastra", "Telangana"],
        }
    }
    render() {
        var states = this.state.states.map(function (i) {
            return <option value={i}>{i}</option>
        })
        return states
    }
}

class AddCustomer extends Component {
    constructor() {
        super()
        this.state = {
            customers: [],
            message: null,
            showCustomerDetails: false
        }
    }
    addCustomer() {
        var customer = {
            "fname": this.refs.cfname.value,
            "lname": this.refs.clname.value,
            "city": this.refs.ccity.value,
            "state": this.refs.cstate.value,
            "email": this.refs.cemail.value
        }
        this.state.customers.push(customer);
        this.setState({ customers: this.state.customers, message: "Successfully Inserted" })
        console.log(this.state.customers)
    }
    updateCustomer(data, index) {
        console.log(data)
        this.state.customers[index] = data;
        console.log(this.state.customers);
        this.setState({ customers: this.state.customers })
        console.log("Updated")
    }
    showSearch() {
        this.setState({ showCustomerDetails: true })
    }
    render() {
        return (
            <div>
                {
                    this.state.showCustomerDetails ? <div><DisplayCustomers customers={this.state.customers} /> <SearchCustomer customerData={this.state.customers} updateCustomer={this.updateCustomer.bind(this)} /></div>
                        :
                        <div>

                            <h1>Add Customers</h1>
                            <form className="form-horizontal">
                                <div className="form-group">
                                    <label className="control-label col-md-6">
                                        First Name:
                                    </label>
                                    <input className="col-md-1" type="text" ref="cfname" />
                                </div>
                                <div className="form-group">
                                    <label className="control-label col-md-6"> Last Name:
                                                    </label>
                                    <input className="col-md-1" type="text" ref="clname" />
                                </div>

                                <div className="form-group">
                                    <label className="control-label col-md-6">
                                        City:
                                    </label>
                                    <select className="col-md-1" ref="ccity"><City /></select>
                                </div>
                                <div className="form-group">
                                    <label className="control-label col-md-6">
                                        State:
                                </label>
                                    <select className="col-md-1" ref="cstate"><State /></select>
                                </div>
                                <div className="form-group">
                                    <label className="control-label col-md-6">
                                        Email:
                                </label>
                                    <input className="col-md-1" type="email" ref="cemail" />
                                </div>
                                <input className="col-md-offset-6 col-md-10" type="submit" onClick={this.addCustomer.bind(this)} />
                                <br />
                                <h5 style={{ color: "green" }}>{this.state.message}</h5>
                                <br />
                                <br />
                                <button className="col-md-offset-6 col-md-10" onClick={this.showSearch.bind(this)}>Search</button>
                                </form>
                        </div>
                            }

            </div>
        )
                }
}

export default AddCustomer;