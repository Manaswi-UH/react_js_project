import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css'; 
import Login from './Login';
import Register from './Register';
import AddCustomer from './AddCustomer'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';


class App extends Component {
  constructor(){
    super()
    this.state = {
      db_users: [{name:"user", username:"user", password:"123"}],
      validUser: false,
      showRegister: false,
      showLogin: true,
      loginRegister: "Register",
      showLoginErrorMessage: false
    }
  }
  registerAdmin(value){
    this.state.db_users.push(value);
    this.setState(this.state)
    alert("Registration successful")
  }
  loginAdmin(value){
    if(value)
      this.setState({validUser: true, showLoginErrorMessage: false, showLogin: false, loginRegister: "Logout"})
    else{
      alert("Wrong username or password")
    }
  }
  // showRegister(){
  //   if(this.state.loginRegister == "Logout")
  //     this.setState({showRegister: false, showLogin: true, registeredMessage: "", showLoginErrorMessage: false, loginRegister: "Register", validUser: false})
  //   else{
  //     this.setState({showRegister: !this.state.showRegister, showLogin: !this.state.showLogin, registeredMessage: "", showLoginErrorMessage: false})
  //     if(this.state.loginRegister == "Register")
  //       this.state.loginRegister = "Back"
  //     else
  //       this.state.loginRegister = "Register"    
  //   }
  // }
  render() {
      var validUser = false;
      return (
      <div className="App">
        <Login db_users={this.state.db_users} validUserCheck={this.loginAdmin.bind(this)}/>
        <Register db_users={this.state.db_users} loginRegister={this.registerAdmin.bind(this)} />
        {this.state.validUser && (this.state.showLogin == false)? <AddCustomer /> :null}
      </div>
    );
  }
}

export default App;