import React, { Component } from 'react';
import { Bootstrap, Grid, Row, Col } from 'react-bootstrap';
import './App.css';


class Login extends Component {
    check() {
        var usersData = this.props.db_users;
        var username = this.refs.username_login.value;
        var password = this.refs.pwd_login.value;
        var valid;
        console.log(usersData)
        for (var i in usersData) {
            console.log(usersData[i].username + " " + usersData[i].password)
            if ((username == usersData[i].username) && (password == usersData[i].password)) {
                valid = true;
                break;
            } else {
                valid = false;

            }
        }
        this.props.validUserCheck(valid)
    }
    render() {
        return (
           <div>
                <h3>Login</h3>
                <form className="form-horizontal">
                    <div className="form-group">
                        <label className="control-label col-md-6">Username:</label>
                        <input className="col-md-1" type="text" placeholder="Username" ref="username_login" required /></div>
                    <div className="form-group">
                        <label className="control-label col-md-6">  Password:</label>
                        <input class="col-md-1" type="password" placeholder="Password" ref="pwd_login" required/></div>
                    <input className="col-md-offset-6 col-md-10" type="submit" onClick={this.check.bind(this)} />
                </form>
           </div>
        );
    }
}

export default Login;