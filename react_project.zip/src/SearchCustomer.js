import React, {Component} from 'react';
import EditCustomer from './EditCustomer'

class DisplaySearchResult extends Component{
	render(){
		console.log(this.props.searchResult)
		if(this.props.searchResult!=null){
			console.log(this.props.searchResult.fname)
			return(
				<div>
					<h5 style={{color:"green"}}>Search result:</h5>
					<table border="solid">
						<th>First Name</th>
						<th>Last Name</th>
						<th>City</th>
						<th>State</th>
						<th>Email</th>
						<tr>
							<td>{this.props.searchResult.fname}</td>
							<td>{this.props.searchResult.lname}</td>
							<td>{this.props.searchResult.city}</td>
							<td>{this.props.searchResult.state}</td>
							<td>{this.props.searchResult.email}</td>
						</tr>
					</table>
				</div>
			)
		}
		else
			return null
	}
}
var count;
class SearchCustomer extends Component{
	constructor(){
		super()
		this.state = {
			customerData: null,
			showEdit: false,
			search: false
		}
	}
	searchCust(updatedData){
		console.log(updatedData)
		var data = this.props.customerData;
		console.log(updatedData.fname)
		if(!updatedData.fname){
			console.log("Search Part")
			console.log(data)
			var fname = this.refs.searchFName.value
			var lname = this.refs.searchLName.value
			var index = data.map(function(i, k){
				if(i.fname == fname && i.lname == lname){
					console.log("Found at position "+k)
					count = k;
					console.log(count)
					return
				}
			})
			console.log(count)
			console.log(data[count])
			if(data[count]){
				this.setState({search: true})
			}else{
				console.log("Here")
				this.setState({search: false})
			}
			console.log(this.state.search)
			this.setState({customerData: data[count]})
		}else{
			console.log("Edit Part")
			this.setState({search: false})
			console.log(this.state.search)
			this.props.updateCustomer(updatedData, count)
		}
	}

	showEdit(){
		this.setState({showEdit: !this.state.showEdit})
	}

	render(){
		return(
			<div>
				<center>
					<br />
					<h5>Search</h5>
					<table>
						<tr><td>First Name</td><td><input type="text" ref="searchFName" /></td></tr>
						<tr><td>Last Name</td><td><input type="text" ref="searchLName" /></td></tr>
					</table>
					<button onClick={this.searchCust.bind(this)}>Search</button>
					<br /><br />
					{this.state.search==true? <div><DisplaySearchResult searchResult={this.state.customerData} /><br /><button onClick={this.showEdit.bind(this)}>Edit</button></div> : null}
					{this.state.showEdit? <EditCustomer editCustomer={this.searchCust.bind(this)} /> : null }
				</center>
			</div>
		)
	}
}

export default SearchCustomer;