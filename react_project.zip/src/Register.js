import React, { Component } from 'react';

class Register extends Component{
  loginUser(){
    this.props.loginRegister({"name":this.refs.nametb.value, "username": this.refs.usernametb.value, "password": this.refs.passwordtb.value})
  }
  render(){
    console.log(this.props.admins)
    return(
      <div>
        <h5>Register</h5><br />
        <center>
        <table>
          <tr>
            <td>Name:</td><td><input type="text"  ref="nametb"/></td>
          </tr>
          <tr>
            <td>Username:</td><td><input type="text"  ref="usernametb"/></td>
          </tr>
          <tr>
          <td>Password</td><td><input type="password"  ref="passwordtb" /></td>
          </tr>
        </table>
        <br />
        </center>
        <input type="submit" onClick={this.loginUser.bind(this)} />
      </div> 
    )
  }
}

export default Register;