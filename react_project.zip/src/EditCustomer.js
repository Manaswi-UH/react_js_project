import React, {Component} from 'react'

class City extends Component{
    constructor(){
        super()
        this.state = {
            cities: ["Bangalore", "Kochi", "Mumbai", "Bangalore", "New-Delhi"]
        }
    }
    render(){
        var cities = this.state.cities.map(function(i){
            return <option value={i}>{i}</option>
        })
        return cities
    }
}

class State extends Component{
    constructor(){
        super()
        this.state = {
            states: ["Karnataka", "TamilNadu", "Maharastra", "Kerala", "Delhi"],
        }
    }
    render(){
        var states = this.state.states.map(function(i){
            return <option value={i}>{i}</option>
        })
        return states
    }
}

class EditCustomer extends Component{
	editCustomer(){
		var customerData = {
			"fname": this.refs.cfname.value,
			"lname": this.refs.clname.value,
			"city": this.refs.ccity.value,
			"state": this.refs.cstate.value,
			"email": this.refs.cemail.value
		}
		this.props.editCustomer(customerData);
	}
	render(){
		return(
			<div>
			    <h3>Edit Customer</h3>
			    <center>
			        <table>
			            <tr>
			                <td>First Name:</td><td><input type="text" ref="cfname" /></td>
			            </tr>
			            <tr>
			                <td>Last Name:</td><td><input type="text" ref="clname" /></td>
			            </tr>
			            <tr>
			                <td>City:</td><td><select ref="ccity"><City /></select></td>
			            </tr>
			            <tr>
			                <td>State:</td><td><select ref="cstate"><State /></select></td>
			            </tr>
			            <tr>
			                <td>Email:</td><td><input type="email" ref="cemail" /></td>
			            </tr>
			        </table>
			    </center>
			    <br />
			    <input type="submit" onClick={this.editCustomer.bind(this)} value="Submit Changes"/>
			</div>
		)
	}
}
export default EditCustomer