import React, { Component } from 'react';

class Login extends Component{
    check(){
        var adminsData = this.props.admins
        var username = this.refs.lUsername.value
        var password = this.refs.lPassword.value
        var valid;
        console.log(adminsData)
        for(var i in adminsData){
            console.log(adminsData[i].username+" "+adminsData[i].password)
            if((username==adminsData[i].username) && (password==adminsData[i].password)){
                valid = true
                break
            }else{
                valid = false
                
            }
        }
        this.props.validUserCheck(valid)
    }
    render(){
        return(
            <div>
                <h5>Login</h5>
                Username: <input type="text" ref="lUsername" /><br /><br />
                Password: <input type="password" ref="lPassword" /><br /><br />
                <input type="submit" onClick={this.check.bind(this)}/>
            </div>
        )
    }
}

export default Login;